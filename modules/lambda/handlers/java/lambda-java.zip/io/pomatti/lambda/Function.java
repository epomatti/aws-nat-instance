package io.pomatti.lambda;

public class Function {

  public void handleRequest() {
    System.out.println("Deployment Lambda function");
  }

}
