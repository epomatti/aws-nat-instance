"""Starter code for the lambda handler."""

def lambda_handler(event, context):
    """Lambda handler function."""
    print("Handler called!")
  